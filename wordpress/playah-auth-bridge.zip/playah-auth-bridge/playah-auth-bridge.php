<?php
/**
 * Plugin Name: PlayAh Auth Bridge
 * Description: Customer auth bridge for PlayAh storefront sessions.
 * Version: 0.1.0
 * Author: PlayAh
 */

if (!defined('ABSPATH')) {
    exit;
}

const PLAYAH_AUTH_NAMESPACE = 'playah/v1';
const PLAYAH_AUTH_SESSION_TTL = WEEK_IN_SECONDS;
const PLAYAH_AUTH_RATE_LIMIT = 5;
const PLAYAH_AUTH_RATE_WINDOW = 15 * MINUTE_IN_SECONDS;

register_activation_hook(__FILE__, 'playah_auth_bridge_activate');
add_action('rest_api_init', 'playah_auth_bridge_register_routes');
add_filter('rest_pre_serve_request', 'playah_auth_bridge_send_cors_headers', 10, 4);

function playah_auth_bridge_activate(): void
{
    global $wpdb;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $table = playah_auth_bridge_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    dbDelta("CREATE TABLE {$table} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        token_hash char(64) NOT NULL,
        user_id bigint(20) unsigned NOT NULL,
        expires_at datetime NOT NULL,
        revoked_at datetime DEFAULT NULL,
        created_at datetime NOT NULL,
        last_seen_at datetime DEFAULT NULL,
        ip_hash char(64) DEFAULT NULL,
        user_agent varchar(255) DEFAULT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY token_hash (token_hash),
        KEY user_id (user_id),
        KEY expires_at (expires_at)
    ) {$charset_collate};");
}

function playah_auth_bridge_register_routes(): void
{
    register_rest_route(PLAYAH_AUTH_NAMESPACE, '/login', [
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'playah_auth_bridge_login',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route(PLAYAH_AUTH_NAMESPACE, '/register', [
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'playah_auth_bridge_register',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route(PLAYAH_AUTH_NAMESPACE, '/me', [
        'methods' => WP_REST_Server::READABLE,
        'callback' => 'playah_auth_bridge_me',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route(PLAYAH_AUTH_NAMESPACE, '/logout', [
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'playah_auth_bridge_logout',
        'permission_callback' => '__return_true',
    ]);
}

function playah_auth_bridge_login(WP_REST_Request $request)
{
    $params = playah_auth_bridge_json_params($request);
    $email = sanitize_email($params['email'] ?? '');
    $password = (string) ($params['password'] ?? '');

    if (!is_email($email) || strlen($password) < 6) {
        return playah_auth_bridge_error('playah_invalid_credentials', 'Email hoặc mật khẩu không đúng.', 401);
    }

    if (!playah_auth_bridge_check_rate_limit('login', $email)) {
        return playah_auth_bridge_error('playah_rate_limited', 'Bạn thử quá nhiều lần. Vui lòng quay lại sau vài phút.', 429);
    }

    $user = wp_authenticate($email, $password);

    if (is_wp_error($user)) {
        return playah_auth_bridge_error('playah_invalid_credentials', 'Email hoặc mật khẩu không đúng.', 401);
    }

    $token = playah_auth_bridge_create_session((int) $user->ID);

    return new WP_REST_Response([
        'ok' => true,
        'token' => $token,
        'user' => playah_auth_bridge_user_payload($user),
    ], 200);
}

function playah_auth_bridge_register(WP_REST_Request $request)
{
    $params = playah_auth_bridge_json_params($request);
    $email = sanitize_email($params['email'] ?? '');
    $password = (string) ($params['password'] ?? '');
    $first_name = sanitize_text_field($params['firstName'] ?? '');
    $last_name = sanitize_text_field($params['lastName'] ?? '');
    $phone = sanitize_text_field($params['phone'] ?? '');

    if (!is_email($email) || strlen($password) < 6 || $first_name === '' || $last_name === '') {
        return playah_auth_bridge_error('playah_invalid_register', 'Thông tin đăng ký chưa hợp lệ.', 400);
    }

    if (!playah_auth_bridge_check_rate_limit('register', $email)) {
        return playah_auth_bridge_error('playah_rate_limited', 'Bạn thử quá nhiều lần. Vui lòng quay lại sau vài phút.', 429);
    }

    if (email_exists($email) || username_exists($email)) {
        return playah_auth_bridge_error('playah_existing_customer', 'Email này đã có tài khoản.', 409);
    }

    $user_id = wp_create_user($email, $password, $email);

    if (is_wp_error($user_id)) {
        return playah_auth_bridge_error($user_id->get_error_code(), $user_id->get_error_message(), 400);
    }

    wp_update_user([
        'ID' => $user_id,
        'first_name' => $first_name,
        'last_name' => $last_name,
    ]);

    $user = get_user_by('id', $user_id);
    if ($user instanceof WP_User) {
        $role = get_role('customer') ? 'customer' : 'subscriber';
        $user->set_role($role);
    }

    update_user_meta($user_id, 'billing_first_name', $first_name);
    update_user_meta($user_id, 'billing_last_name', $last_name);
    update_user_meta($user_id, 'billing_phone', $phone);

    $token = playah_auth_bridge_create_session((int) $user_id);

    return new WP_REST_Response([
        'ok' => true,
        'token' => $token,
        'user' => playah_auth_bridge_user_payload(get_user_by('id', $user_id)),
    ], 201);
}

function playah_auth_bridge_me(WP_REST_Request $request)
{
    $session = playah_auth_bridge_get_session_from_request($request);

    if (!$session) {
        return playah_auth_bridge_error('playah_invalid_session', 'Phiên đăng nhập đã hết hạn.', 401);
    }

    $user = get_user_by('id', (int) $session['user_id']);

    if (!$user instanceof WP_User) {
        return playah_auth_bridge_error('playah_invalid_session', 'Phiên đăng nhập đã hết hạn.', 401);
    }

    playah_auth_bridge_touch_session((int) $session['id']);

    return new WP_REST_Response([
        'ok' => true,
        'user' => playah_auth_bridge_user_payload($user),
    ], 200);
}

function playah_auth_bridge_logout(WP_REST_Request $request)
{
    $session = playah_auth_bridge_get_session_from_request($request);

    if ($session) {
        playah_auth_bridge_revoke_session((int) $session['id']);
    }

    return new WP_REST_Response(['ok' => true], 200);
}

function playah_auth_bridge_create_session(int $user_id): string
{
    global $wpdb;

    playah_auth_bridge_cleanup_expired_sessions();

    $token = bin2hex(random_bytes(32));
    $now = current_time('mysql', true);
    $expires = gmdate('Y-m-d H:i:s', time() + PLAYAH_AUTH_SESSION_TTL);

    $wpdb->insert(playah_auth_bridge_table_name(), [
        'token_hash' => playah_auth_bridge_hash_token($token),
        'user_id' => $user_id,
        'expires_at' => $expires,
        'created_at' => $now,
        'last_seen_at' => $now,
        'ip_hash' => playah_auth_bridge_hash_ip(playah_auth_bridge_client_ip()),
        'user_agent' => substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
    ], ['%s', '%d', '%s', '%s', '%s', '%s', '%s']);

    return $token;
}

function playah_auth_bridge_get_session_from_request(WP_REST_Request $request): ?array
{
    global $wpdb;

    $token = playah_auth_bridge_bearer_token($request);
    if ($token === '') {
        return null;
    }

    $session = $wpdb->get_row(
        $wpdb->prepare(
            'SELECT * FROM ' . playah_auth_bridge_table_name() . ' WHERE token_hash = %s AND revoked_at IS NULL AND expires_at > %s LIMIT 1',
            playah_auth_bridge_hash_token($token),
            current_time('mysql', true)
        ),
        ARRAY_A
    );

    return is_array($session) ? $session : null;
}

function playah_auth_bridge_touch_session(int $session_id): void
{
    global $wpdb;

    $wpdb->update(playah_auth_bridge_table_name(), ['last_seen_at' => current_time('mysql', true)], ['id' => $session_id], ['%s'], ['%d']);
}

function playah_auth_bridge_revoke_session(int $session_id): void
{
    global $wpdb;

    $wpdb->update(playah_auth_bridge_table_name(), ['revoked_at' => current_time('mysql', true)], ['id' => $session_id], ['%s'], ['%d']);
}

function playah_auth_bridge_cleanup_expired_sessions(): void
{
    global $wpdb;

    $wpdb->query($wpdb->prepare('DELETE FROM ' . playah_auth_bridge_table_name() . ' WHERE expires_at <= %s OR revoked_at IS NOT NULL', current_time('mysql', true)));
}

function playah_auth_bridge_check_rate_limit(string $action, string $email): bool
{
    $key = 'playah_auth_rate_' . md5($action . '|' . strtolower($email) . '|' . playah_auth_bridge_client_ip());
    $count = (int) get_transient($key);

    if ($count >= PLAYAH_AUTH_RATE_LIMIT) {
        return false;
    }

    set_transient($key, $count + 1, PLAYAH_AUTH_RATE_WINDOW);

    return true;
}

function playah_auth_bridge_user_payload($user): array
{
    if (!$user instanceof WP_User) {
        return [];
    }

    return [
        'id' => (int) $user->ID,
        'email' => $user->user_email,
        'firstName' => get_user_meta($user->ID, 'first_name', true) ?: get_user_meta($user->ID, 'billing_first_name', true),
        'lastName' => get_user_meta($user->ID, 'last_name', true) ?: get_user_meta($user->ID, 'billing_last_name', true),
        'phone' => get_user_meta($user->ID, 'billing_phone', true),
    ];
}

function playah_auth_bridge_bearer_token(WP_REST_Request $request): string
{
    $header = $request->get_header('authorization');
    if (!$header && isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $header = sanitize_text_field(wp_unslash($_SERVER['HTTP_AUTHORIZATION']));
    }
    if (!$header && isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $header = sanitize_text_field(wp_unslash($_SERVER['REDIRECT_HTTP_AUTHORIZATION']));
    }

    if (is_string($header) && preg_match('/Bearer\s+(.*)$/i', $header, $matches)) {
        return trim($matches[1]);
    }

    return '';
}

function playah_auth_bridge_hash_token(string $token): string
{
    return hash_hmac('sha256', $token, wp_salt('auth'));
}

function playah_auth_bridge_hash_ip(string $ip): string
{
    return $ip === '' ? '' : hash_hmac('sha256', $ip, wp_salt('nonce'));
}

function playah_auth_bridge_client_ip(): string
{
    return sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? ''));
}

function playah_auth_bridge_table_name(): string
{
    global $wpdb;

    return $wpdb->prefix . 'playah_customer_sessions';
}

function playah_auth_bridge_json_params(WP_REST_Request $request): array
{
    $params = $request->get_json_params();

    return is_array($params) ? $params : [];
}

function playah_auth_bridge_error(string $code, string $message, int $status): WP_Error
{
    return new WP_Error($code, $message, ['status' => $status, 'ok' => false]);
}

function playah_auth_bridge_send_cors_headers(bool $served, WP_HTTP_Response $result, WP_REST_Request $request, WP_REST_Server $server): bool
{
    if (strpos($request->get_route(), '/' . PLAYAH_AUTH_NAMESPACE . '/') !== 0) {
        return $served;
    }

    $origin = get_http_origin();
    $allowed_origin = defined('PLAYAH_STOREFRONT_ORIGIN') ? PLAYAH_STOREFRONT_ORIGIN : '';

    if ($origin && $allowed_origin && $origin === $allowed_origin) {
        header('Access-Control-Allow-Origin: ' . esc_url_raw($origin));
        header('Vary: Origin', false);
        header('Access-Control-Allow-Headers: Authorization, Content-Type');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    }

    return $served;
}
